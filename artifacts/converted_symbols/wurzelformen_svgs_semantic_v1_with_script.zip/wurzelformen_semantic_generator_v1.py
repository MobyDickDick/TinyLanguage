#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
wurzelformen_semantic_generator_v1.py

Ziel:
- Aus (Wurzelform, Beschreibung)-Resolver-Output (wurzelformen_resolved_v2.csv) + PNGs
  "semantische" SVGs erzeugen, die aus wenigen Primitiven bestehen:
    <rect>, <line>, (optional) <linearGradient>
- Verweise vom Typ "Wie XYZ, ... gedreht/gespiegelt" werden aufgelöst, indem die Basis-SVG
  übernommen und per transform gedreht/gespiegelt wird.
- Für Fälle mit Hintergrund/Vordergrund/Komponenten-Refs: Fallback (z.B. kompakte Path-SVGs).
- Zusätzlich wird ein Log mit Elementanzahl + Diff (optional, wenn PyMuPDF vorhanden) geschrieben.

Hinweis:
Das ist eine robuste Baseline. Für wirklich kleine Diff-Fehler braucht es später
bessere Parameter-Fits pro Beschreibung (Positions-/Dicken-/Farb-Schätzung).
"""

import os, re, json, math, csv, argparse
import numpy as np
import cv2

try:
    import fitz  # PyMuPDF
except Exception:
    fitz = None


def safe_name(s: str) -> str:
    return re.sub(r'[^A-Za-z0-9_.-]+', '_', str(s).strip())


def bgr_to_hex(bgr):
    b, g, r = [int(x) for x in bgr]
    return f"#{r:02x}{g:02x}{b:02x}"


def load_png_as_bgr(png_dir: str, code: str):
    p = os.path.join(png_dir, f"{safe_name(code)}.png")
    img = cv2.imread(p, cv2.IMREAD_UNCHANGED)
    if img is None:
        return None
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    if img.ndim == 3 and img.shape[2] == 4:
        alpha = img[:, :, 3:4].astype(np.float32) / 255.0
        rgb = img[:, :, :3].astype(np.float32)
        white = np.ones_like(rgb) * 255.0
        rgb = rgb * alpha + white * (1 - alpha)
        img = rgb.astype(np.uint8)
    return img


def render_svg_to_bgr(svg_string: str, w: int, h: int):
    if fitz is None:
        return None
    doc = fitz.open(stream=svg_string.encode("utf-8"), filetype="svg")
    page = doc[0]
    sx = w / page.rect.width if page.rect.width else 1.0
    sy = h / page.rect.height if page.rect.height else 1.0
    pix = page.get_pixmap(matrix=fitz.Matrix(sx, sy), alpha=False)
    img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, 3)
    return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)


def mean_abs_diff(a: np.ndarray, b: np.ndarray) -> float:
    if a is None or b is None or a.shape != b.shape:
        return float("inf")
    return float(np.mean(cv2.absdiff(a, b)))


def robust_bg_color(img_bgr):
    small = cv2.resize(img_bgr, (max(1, img_bgr.shape[1]//2), max(1, img_bgr.shape[0]//2)), interpolation=cv2.INTER_AREA)
    data = small.reshape(-1, 3)
    q = (data // 8) * 8
    uniq, cnt = np.unique(q, axis=0, return_counts=True)
    bg = uniq[np.argmax(cnt)]
    return (int(bg[0]), int(bg[1]), int(bg[2]))


def detect_main_rect(img_bgr):
    h, w = img_bgr.shape[:2]
    scale = 8
    up = cv2.resize(img_bgr, (w*scale, h*scale), interpolation=cv2.INTER_NEAREST)
    gray = cv2.cvtColor(up, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 40, 120)
    edges = cv2.dilate(edges, np.ones((3,3), np.uint8), iterations=1)
    edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, np.ones((5,5), np.uint8), iterations=1)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    full_area = (w*scale)*(h*scale)
    best=None; best_area=-1
    for c in contours:
        area = cv2.contourArea(c)
        x,y,ww,hh = cv2.boundingRect(c)
        if ww*hh > 0.98*full_area:
            continue
        if area > best_area:
            best_area=area; best=(x,y,ww,hh)
    if best is None:
        return None
    x,y,ww,hh = best
    bx = max(0, int(round(x/scale))); by = max(0, int(round(y/scale)))
    bw = min(w-bx, max(1, int(round(ww/scale))))
    bh = min(h-by, max(1, int(round(hh/scale))))
    return (bx,by,bw,bh)


def sample_fill_and_stroke(img_bgr, bbox, bg_bgr):
    x,y,w,h = bbox
    roi = img_bgr[y:y+h, x:x+w]
    if roi.size == 0:
        return "#ffffff", "#808080", 1
    border = np.concatenate([roi[0:1,:,:].reshape(-1,3), roi[-1:,:,:].reshape(-1,3),
                             roi[:,0:1,:].reshape(-1,3), roi[:,-1:,:].reshape(-1,3)], axis=0)
    ix0 = max(0, int(w*0.2)); ix1 = max(ix0+1, int(w*0.8))
    iy0 = max(0, int(h*0.2)); iy1 = max(iy0+1, int(h*0.8))
    inner = roi[iy0:iy1, ix0:ix1, :].reshape(-1,3)

    med_inner = np.median(inner, axis=0) if inner.size else np.array([255,255,255])
    med_border = np.median(border, axis=0) if border.size else np.array([128,128,128])

    fill = bgr_to_hex(med_inner)
    stroke = bgr_to_hex(med_border)

    bg = np.array(bg_bgr, dtype=np.float32)
    border_diff = np.mean(np.abs(border.astype(np.float32)-bg), axis=1) if border.size else np.array([0.0])
    frac = float(np.mean(border_diff > 12))
    sw = 1 if frac < 0.10 else max(1, int(round(min(img_bgr.shape[:2]) * 0.06)))
    return fill, stroke, sw


def estimate_gradient(img_bgr, bbox):
    x, y, w, h = bbox
    roi = img_bgr[y:y+h, x:x+w]
    if roi.size == 0:
        return None
    cols = roi.mean(axis=0); rows = roi.mean(axis=1)
    var_h = float(cols.var(axis=0).mean()); var_v = float(rows.var(axis=0).mean())
    direction = "h" if var_h >= var_v else "v"
    if direction == "h":
        a = cols[0]; m = cols[len(cols)//2]; b = cols[-1]
    else:
        a = rows[0]; m = rows[len(rows)//2]; b = rows[-1]
    ends_avg = (a + b) / 2.0
    delta = float(np.abs(m - ends_avg).mean())
    if delta > 8:
        stops = [(0.0, bgr_to_hex(a)), (0.5, bgr_to_hex(m)), (1.0, bgr_to_hex(b))]
    else:
        stops = [(0.0, bgr_to_hex(a)), (1.0, bgr_to_hex(b))]
    return direction, stops


def detect_lines(img_bgr, max_lines=4, exclude_bbox=None):
    h, w = img_bgr.shape[:2]
    scale = 8
    up = cv2.resize(img_bgr, (w*scale, h*scale), interpolation=cv2.INTER_NEAREST)
    gray = cv2.cvtColor(up, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 40, 120)
    edges = cv2.dilate(edges, np.ones((3,3), np.uint8), iterations=1)

    if exclude_bbox is not None:
        x,y,bw,bh = exclude_bbox
        x*=scale; y*=scale; bw*=scale; bh*=scale
        pad = max(2, int(min(bw,bh)*0.04))
        x0=max(0,x-pad); y0=max(0,y-pad); x1=min(w*scale, x+bw+pad); y1=min(h*scale, y+bh+pad)
        edges[y0:y1, x0:x1] = 0

    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=30, minLineLength=10, maxLineGap=8)
    if lines is None:
        return []
    segs=[]
    for x1,y1,x2,y2 in lines[:,0,:]:
        L = math.hypot(x2-x1, y2-y1)
        if L < 12:
            continue
        segs.append((x1/scale,y1/scale,x2/scale,y2/scale,L))
    segs.sort(key=lambda s: -s[4])

    picked=[]
    seen=set()
    for x1,y1,x2,y2,L in segs:
        mx=(x1+x2)/2; my=(y1+y2)/2
        ang=int(math.degrees(math.atan2(y2-y1, x2-x1))/10)
        key=(int(mx*2), int(my*2), ang)
        if key in seen:
            continue
        seen.add(key)
        picked.append((x1,y1,x2,y2,L))
        if len(picked) >= max_lines:
            break

    out=[]
    for x1,y1,x2,y2,L in picked:
        pts=[]
        for t in np.linspace(0,1,8):
            xx=int(round(x1*(1-t)+x2*t))
            yy=int(round(y1*(1-t)+y2*t))
            if 0<=xx<w and 0<=yy<h:
                pts.append(img_bgr[yy,xx,:])
        col = bgr_to_hex(np.median(np.array(pts), axis=0)) if pts else "#808080"
        sw = max(1, int(round(min(w,h)*0.06)))
        out.append({"x1":x1,"y1":y1,"x2":x2,"y2":y2,"stroke":col,"sw":sw})
    return out


def apply_transforms(transforms, w, h):
    ops=[]
    for t in transforms:
        if t.get("op")=="mirror":
            axis=t.get("axis")
            if axis=="horizontal":
                ops.append(f"translate(0 {h}) scale(1 -1)")
            elif axis=="vertical":
                ops.append(f"translate({w} 0) scale(-1 1)")
    for t in transforms:
        if t.get("op")=="rotate":
            deg=t.get("deg")
            if deg in (90, -90, 180):
                ops.append(f"rotate({deg} {w/2:.2f} {h/2:.2f})")
    return " ".join(ops) if ops else None


STYLE_WORDS = set("""
heller dunkler fetter dünner duenner gestrichelt punktiert blasser kräftiger kraeftiger kontrast farbe farbig
grau graues grauer rot blau grün gruen gelb orange violett schwarz weiß weiss gezeichnet skaliert vergrößert vergroessert verkleinert
rechts links oben unten mittig zentriert text
""".split())


def looks_style_only(text: str) -> bool:
    t = re.sub(r'[^a-zäöüß ]+', ' ', str(text).lower())
    toks=[x for x in t.split() if x]
    if not toks:
        return True
    geom_words = {"rechteck","viereck","quadrat","kreis","ellipse","dreieck","linie","strich","diagonale","farbverlauf","pfeil","kreuz","plus","minus"}
    if any(w in t for w in geom_words):
        return False
    return all((tok in STYLE_WORDS) or (len(tok)<=2) for tok in toks)


def build_semantic_svg_from_png(code, img_bgr, prims_total, transforms, raw_desc):
    h, w = img_bgr.shape[:2]
    bg = robust_bg_color(img_bgr)

    expect_grad = int(prims_total.get("gradient", 0)) > 0 or ("farbverlauf" in str(raw_desc).lower())
    expect_rect = int(prims_total.get("rect", 0)) > 0 or ("rechteck" in str(raw_desc).lower()) or ("viereck" in str(raw_desc).lower())
    expect_lines = int(prims_total.get("line", 0))

    bbox = detect_main_rect(img_bgr) if expect_rect else None
    if bbox is None:
        bbox = (0,0,w,h)

    fill, stroke, sw = sample_fill_and_stroke(img_bgr, bbox, bg)

    defs=[]; elems=[]
    fill_attr = fill

    if expect_grad:
        gs = estimate_gradient(img_bgr, bbox)
        if gs:
            direction, stops = gs
            gid = f"g_{safe_name(code)}"
            if direction == "h":
                defs.append(f'<linearGradient id="{gid}" x1="0%" y1="0%" x2="100%" y2="0%">')
            else:
                defs.append(f'<linearGradient id="{gid}" x1="0%" y1="0%" x2="0%" y2="100%">')
            for off, col in stops:
                defs.append(f'  <stop offset="{int(off*100)}%" stop-color="{col}"/>')
            defs.append('</linearGradient>')
            fill_attr = f'url(#{gid})'

    x,y,bw,bh = bbox
    rx = 0
    dl = str(raw_desc).lower()
    if "abgerundet" in dl or "rund" in dl:
        rx = max(1, int(round(min(bw,bh)*0.18)))

    if expect_rect:
        if rx:
            elems.append(f'<rect x="{x}" y="{y}" width="{bw}" height="{bh}" rx="{rx}" ry="{rx}" fill="{fill_attr}" stroke="{stroke}" stroke-width="{sw}"/>')
        else:
            elems.append(f'<rect x="{x}" y="{y}" width="{bw}" height="{bh}" fill="{fill_attr}" stroke="{stroke}" stroke-width="{sw}"/>')

    if expect_lines > 0:
        lines = detect_lines(img_bgr, max_lines=min(12, max(1, expect_lines)), exclude_bbox=bbox if expect_rect else None)
        for ln in lines[:expect_lines]:
            elems.append(
                f'<line x1="{ln["x1"]:.2f}" y1="{ln["y1"]:.2f}" x2="{ln["x2"]:.2f}" y2="{ln["y2"]:.2f}" '
                f'stroke="{ln["stroke"]}" stroke-width="{ln["sw"]}" stroke-linecap="round"/>'
            )

    gtf = apply_transforms(transforms, w, h)
    body = "\n".join(elems)
    if gtf:
        body = f'<g transform="{gtf}">\n{body}\n</g>'

    defs_block = "<defs>\n" + "\n".join(defs) + "\n</defs>\n" if defs else ""
    return f'<svg width="{w}px" height="{h}px" viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg">\n{defs_block}{body}\n</svg>'


def count_svg_elements(svg_text: str) -> int:
    tags = ["rect","line","circle","ellipse","polygon","polyline","path","linearGradient","radialGradient"]
    return sum(len(re.findall(rf'(?i)<{t}\b', svg_text)) for t in tags)


def extract_svg_defs_and_body(svg_text: str):
    defs=""
    m=re.search(r'(?is)<defs[^>]*>(.*?)</defs>', svg_text)
    if m:
        defs=m.group(1).strip()
    body = re.sub(r'(?is)<defs[^>]*>.*?</defs>', '', svg_text)
    body = re.sub(r'(?is)^.*?<svg[^>]*>', '', body)
    body = re.sub(r'(?is)</svg>\s*$', '', body)
    return defs.strip(), body.strip()


def rename_ids(defs: str, body: str, prefix: str):
    if defs:
        defs = re.sub(r'id="([^"]+)"', lambda m: f'id="{prefix}_{m.group(1)}"', defs)
        defs = re.sub(r'url\(#([^)]+)\)', lambda m: f'url(#{prefix}_{m.group(1)})', defs)
    if body:
        body = re.sub(r'url\(#([^)]+)\)', lambda m: f'url(#{prefix}_{m.group(1)})', body)
        body = re.sub(r'href="#([^"]+)"', lambda m: f'href="#{prefix}_{m.group(1)}"', body)
    return defs, body


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--resolved", required=True, help="wurzelformen_resolved_v2.csv (Resolver-Output)")
    ap.add_argument("--png-dir", required=True, help="Ordner mit PNGs (Dateinamen = safe_name(code).png)")
    ap.add_argument("--fallback-svg-dir", default="", help="Optional: Ordner mit Fallback-SVGs (z.B. kompakte Path-SVGs)")
    ap.add_argument("--out", required=True, help="Ausgabeordner")
    ap.add_argument("--render", action="store_true", help="SVG rendern und Diff berechnen (benötigt PyMuPDF)")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    svgs_dir = os.path.join(args.out, "svgs")
    os.makedirs(svgs_dir, exist_ok=True)

    previews_dir = os.path.join(args.out, "previews")
    diffs_dir = os.path.join(args.out, "diffs")
    if args.render and fitz is not None:
        os.makedirs(previews_dir, exist_ok=True)
        os.makedirs(diffs_dir, exist_ok=True)

    # Load resolved CSV
    import pandas as pd
    df = pd.read_csv(args.resolved, sep=";").fillna("")
    df["prims_total_obj"] = df["prims_total"].apply(lambda s: json.loads(s) if str(s).strip() else {})
    df["transforms_obj"] = df["transforms"].apply(lambda s: json.loads(s) if str(s).strip() else [])

    # semantic decision rule
    def can_semantic(row):
        full_copy = str(row.get("full_copy_ref","")).strip()
        bg = str(row.get("background_refs","")).strip()
        fg = str(row.get("foreground_refs","")).strip()
        comp = str(row.get("component_refs","")).strip()
        local_text = str(row.get("local_text","")).strip()
        if bg or fg or comp:
            return False
        if full_copy:
            return looks_style_only(local_text)
        return True

    df["can_semantic"] = df.apply(can_semantic, axis=1)

    # caching
    cache = {}
    visiting = set()

    def load_fallback_svg(code: str):
        if not args.fallback_svg_dir:
            return None
        p = os.path.join(args.fallback_svg_dir, f"{safe_name(code)}.svg")
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                return f.read()
        return None

    def make_svg(code: str):
        if code in cache:
            return cache[code]
        if code in visiting:
            svg = load_fallback_svg(code) or '<svg xmlns="http://www.w3.org/2000/svg"></svg>'
            cache[code] = svg
            return svg
        visiting.add(code)

        row = df[df["code"] == code].iloc[0]
        full_copy = str(row.get("full_copy_ref","")).strip()
        local_text = str(row.get("local_text","")).strip()
        transforms = row.get("transforms_obj", [])
        prims_total = row.get("prims_total_obj", {})
        raw_desc = row.get("raw_desc","")

        if bool(row.get("can_semantic", False)):
            if full_copy and looks_style_only(local_text):
                base_svg = make_svg(full_copy)
                img = load_png_as_bgr(args.png_dir, code)
                if img is None:
                    img = load_png_as_bgr(args.png_dir, full_copy)
                if img is None:
                    svg = base_svg
                else:
                    h, w = img.shape[:2]
                    defs, body = extract_svg_defs_and_body(base_svg)
                    prefix = safe_name(code)
                    defs, body = rename_ids(defs, body, prefix)
                    gtf = apply_transforms(transforms, w, h)
                    if gtf:
                        body = f'<g transform="{gtf}">\n{body}\n</g>'
                    defs_block = f"<defs>\n{defs}\n</defs>\n" if defs else ""
                    svg = f'<svg width="{w}px" height="{h}px" viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg">\n{defs_block}{body}\n</svg>'
            else:
                img = load_png_as_bgr(args.png_dir, code)
                if img is None:
                    svg = load_fallback_svg(code) or '<svg xmlns="http://www.w3.org/2000/svg"></svg>'
                else:
                    svg = build_semantic_svg_from_png(code, img, prims_total, transforms, raw_desc)
        else:
            svg = load_fallback_svg(code)
            if svg is None:
                img = load_png_as_bgr(args.png_dir, code)
                svg = build_semantic_svg_from_png(code, img, prims_total, transforms, raw_desc) if img is not None else '<svg xmlns="http://www.w3.org/2000/svg"></svg>'

        cache[code] = svg
        visiting.remove(code)
        return svg

    # run
    log_rows = []
    for _, row in df.iterrows():
        code = row["code"]
        fb = safe_name(code)
        svg = make_svg(code)
        with open(os.path.join(svgs_dir, fb + ".svg"), "w", encoding="utf-8") as f:
            f.write(svg)

        elem_count = count_svg_elements(svg)
        diff = float("inf")

        if args.render and fitz is not None:
            img = load_png_as_bgr(args.png_dir, code)
            if img is not None:
                h, w = img.shape[:2]
                rend = render_svg_to_bgr(svg, w, h)
                diff = mean_abs_diff(img, rend)
                cv2.imwrite(os.path.join(previews_dir, fb + ".jpg"), rend, [int(cv2.IMWRITE_JPEG_QUALITY), 92])
                diff_img = np.zeros_like(img)
                diff_img[:, :, 2] = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                gg = cv2.cvtColor(rend, cv2.COLOR_BGR2GRAY)
                diff_img[:, :, 1] = gg
                diff_img[:, :, 0] = gg
                cv2.imwrite(os.path.join(diffs_dir, fb + "_diff.jpg"), diff_img, [int(cv2.IMWRITE_JPEG_QUALITY), 92])

        method = "semantic" if bool(row.get("can_semantic", False)) else "fallback"
        log_rows.append([code, fb, elem_count, f"{diff:.4f}" if math.isfinite(diff) else "inf", method])

    with open(os.path.join(args.out, "svgs_semantic_v1_log.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["code","file_base","svg_element_count","mean_abs_diff","method"])
        w.writerows(log_rows)

    print("OK:", args.out)


if __name__ == "__main__":
    main()
